TRAVEL 24x7 — ANDROID APK BUILD PROJECT

WHAT THIS ZIP CONTAINS
- www/index.html: Customer App HTML entry page
- Travel_24x7_Admin_Key_Generator_v4.html: separate admin key generator source
- android/: native Android WebView project
- .github/workflows/android.yml: GitHub Actions workflow to build a debug APK

BUILD APK FROM YOUR PHONE USING GITHUB
1. Extract this ZIP on your phone.
2. Open your GitHub repository: https://github.com/arunavaac30-debug/travel-24x7-android
3. Upload the CONTENTS of this extracted folder (not the ZIP itself) to the repository root. Make sure folder paths are preserved, especially:
   - www/index.html
   - android/...
   - .github/workflows/android.yml
   - package.json and capacitor.config.json
4. Commit the upload to the main branch.
5. Open the repository's Actions tab.
6. Select “Build Travel 24x7 Android APK”. If it did not start automatically, tap “Run workflow”.
7. Open the completed workflow run and download the artifact named “Travel-24x7-Android-APK”.
8. Extract the artifact ZIP; it contains app-debug.apk. Transfer/install the APK on your Android phone.

IMPORTANT LIMITATIONS
- This is an initial debug APK build project, not a signed production release.
- The APK opens the Customer App. The admin key generator is bundled separately as android/app/src/main/assets/admin.html, but it is not exposed as a screen in the APK.
- This wrapper does not add secure server-side license validation, cross-device sync, or cloud backups. Offline browser storage can be cleared by Android and does not sync between devices.
- Test with sample data before using it for live customer bookings. Debug APK installation may require allowing installs from the browser/file manager you use.
